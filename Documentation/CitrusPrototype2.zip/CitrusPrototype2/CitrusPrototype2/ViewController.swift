//
//  ViewController.swift
//  CitrusPrototype2
//
//  Created by tscmac2 on 11/19/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        
    }

}
