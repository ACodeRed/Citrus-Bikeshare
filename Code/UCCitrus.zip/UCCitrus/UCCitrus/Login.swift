//
//  Login.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/1/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit

class Login: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var userEmailInput: UITextField!
    
    @IBOutlet weak var userPasswordInput: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.userEmailInput.delegate = self
        self.userPasswordInput.delegate = self

        // Do any additional setup after loading the view.
    }
    
    @IBAction func loginButton(_ sender: Any) {
        
        let userEmail = userEmailInput.text
        let userPassword = userPasswordInput.text
        
        let userEmailStored = UserDefaults.standard.string(forKey: "userEmail")
        let userPasswordStored = UserDefaults.standard.string(forKey: "userpasswords")
        
        if(userEmailStored == userEmail){
            if(userPasswordStored == userPassword){
                //login is successfull
                
                UserDefaults.standard.set(true, forKey: "isUserLoggedIn")
                UserDefaults.standard.synchronize()
                self.dismiss(animated: true, completion: nil)
                
            }
        }
        else{
            displayMyAlertMessage(userMessage: "Wrong email or password. Please try again!")
            return
        }
        
        if(userEmail?.isEmpty ?? true || userPassword?.isEmpty ?? true){
            displayMyAlertMessage(userMessage: "All fields are required!")
            return
        }
        
    }
    
    func displayMyAlertMessage(userMessage: String){
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
        
        myAlert.addAction(okAction)
        
        self.present(myAlert, animated: true, completion: nil)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
