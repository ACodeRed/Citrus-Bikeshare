//
//  Scanner.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/2/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit
import AVFoundation

class Scanner: UIViewController, AVCaptureMetadataOutputObjectsDelegate{
    
    
    @IBOutlet weak var square: UIImageView!
    
    @IBOutlet weak var videoPreview: UIView!
    
    
    
    var video = AVCaptureVideoPreviewLayer()
    var oneTime = 1

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Creating session
        let session = AVCaptureSession()
        
        
        //Define capture device
        let CaptureDevice = AVCaptureDevice.default(for: AVMediaType.video)
        

        // Do any additional setup after loading the view.
        
        do{
            let input = try AVCaptureDeviceInput(device: CaptureDevice!)
            session.addInput(input)
        }
        catch{
            print("Failed to Scan the QR/Barcode.")
        }
        
        let output = AVCaptureMetadataOutput()
        session.addOutput(output)
        
        output.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        output.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
        
        
        video = AVCaptureVideoPreviewLayer(session: session)
        video.videoGravity = AVLayerVideoGravity.resizeAspectFill
        video.frame = videoPreview.bounds
        self.videoPreview.layer.addSublayer(video)
        
        session.startRunning()
        
    }
    
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        
        if metadataObjects.count != 0{
            if let object = metadataObjects[0] as? AVMetadataMachineReadableCodeObject{
                if object.type == AVMetadataObject.ObjectType.qr{
                    if oneTime == 1{
                        UserDefaults.standard.set(object.stringValue, forKey: "QRCodeValue")
                        self.performSegue(withIdentifier: "openTimerCountDown", sender: self)
                        oneTime += 1
                        self.dismiss(animated: true, completion: nil)
                    }
                }
            }
        }
        
        
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
