//
//  Scanner.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/2/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit
import AVFoundation

class Scanner: UIViewController, AVCaptureMetadataOutputObjectsDelegate{
    
    @IBOutlet weak var VideoPreview: UIView!
    
    
    var stringUrl = String()
    
    enum error: Error{
        case noCameraAvailabe
        case videoInputInitFail
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        do{
            try scanQRCode()
        }
        catch{
            print("Failed to Scan the QR/Barcode.")
        }
    }
    
    func captureOutput(_captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!){
        
        if metadataObjects.count > 0{
            let machineReadableCode = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
            
            if machineReadableCode.type == AVMetadataObject.ObjectType.qr{
                stringUrl = machineReadableCode.stringValue!
                performSegue(withIdentifier: "openTimerCountDown", sender: self)
            }
        }
        
    }
    
    
    func scanQRCode() throws{
        let avCaptureSession = AVCaptureSession()
        
        guard let avCaptureDevice = AVCaptureDevice.default(for: AVMediaType.video)else{
            print("No camera.")
            throw error.noCameraAvailabe
        }
        
        guard let avCaptureInput = try? AVCaptureDeviceInput(device: avCaptureDevice)else{
            print("Failed to init camera.")
            throw error.videoInputInitFail
        }
        
        let avCaptureMetadataOutput = AVCaptureMetadataOutput()
        avCaptureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        
        avCaptureSession.addInput(avCaptureInput)
        avCaptureSession.addOutput(avCaptureMetadataOutput)
        
        avCaptureMetadataOutput.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
        
        let avCaptureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session: avCaptureSession)
        avCaptureVideoPreviewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        avCaptureVideoPreviewLayer.frame = VideoPreview.bounds
        self.VideoPreview.layer.addSublayer(avCaptureVideoPreviewLayer)
        
        avCaptureSession.startRunning()
       
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "openTimerCountDown"{
            let destination = segue.destination as! TimeCountDown
            destination.url = URL(string: stringUrl)
        }
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
