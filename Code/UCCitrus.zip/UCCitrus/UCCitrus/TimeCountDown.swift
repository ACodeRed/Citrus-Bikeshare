//
//  TimeCountDown.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/3/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit

class TimeCountDown: UIViewController {
    
    @IBOutlet weak var TimeLabel: UILabel!
    
    
    @IBOutlet weak var MinuteLabel: UILabel!
    
    @IBOutlet weak var SecondLabel: UILabel!
    
    var url = URL(string: "")
    
    var url2 = URL(string: "https://www.google.com/")
    
    var second = 00
    var minute = 0
    var time = 0
    
    var timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if(url == url2){
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(TimeCountDown.action), userInfo: nil, repeats: true)
        }
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func EndRideButton(_ sender: Any) {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(TimeCountDown.action), userInfo: nil, repeats: false)
    }
    
    @IBAction func PauseRideButton(_ sender: Any) {
        timer.invalidate()
    }
    
    @IBAction func CountinueRideButton(_ sender: Any) {
        
    }
    
    @objc func action(){
        second += 1
        SecondLabel.text = String(second)
        if(SecondLabel.text == "60"){
            
            second = 00
            minute += 1
            SecondLabel.text = String(second)
            MinuteLabel.text = String(minute)
        }
        if(MinuteLabel.text == "60"){
            minute = 00
            time += 1
            MinuteLabel.text = String(minute)
            TimeLabel.text = String(time)
        }
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
