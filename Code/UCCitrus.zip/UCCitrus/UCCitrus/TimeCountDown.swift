//
//  TimeCountDown.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/3/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit

class TimeCountDown: UIViewController {
    
    
    
    @IBOutlet weak var dragView: UIView!
    @IBOutlet weak var RealTimeDate: UILabel!
    
    @IBOutlet var gestureRecognizer: UIPanGestureRecognizer!
    
    @IBOutlet weak var TimeLabel: UILabel!
    
    
    @IBOutlet weak var MinuteLabel: UILabel!
    
    @IBOutlet weak var SecondLabel: UILabel!
    
    //var url1 = URL(string: "")
    
    var str2 = "christianndaye"
    //var url2 = URL(string: "")
    
    var second = 00
    var minute = 00
    var time = 00
    
    var timer = Timer()
    var timing = ""
    var dating = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkingCondition()
        getCurrentDate()
        // Do any additional setup after loading the view.
        
        dragView.layer.shadowOffset = CGSize(width: 1, height: 1)
        dragView.layer.shadowRadius = 1.4
        dragView.layer.shadowOpacity = 0.3
        
        
    }
    
    func getCurrentDate(){
        let formatterD = DateFormatter()
        let formatterDt = DateFormatter()
        let formatterT = DateFormatter()
        
        formatterD.dateFormat = "EEEE, MMMM, dd, yyyy, HH:mm:ss a"
        formatterDt.dateFormat = "MMMM, dd "
        formatterT.dateFormat = "HH:mm:ss a"
        
        let strd = formatterD.string(from: Date())
        let strdt = formatterDt.string(from: Date())
        let strt = formatterT.string(from: Date())
        
        RealTimeDate.text = strd
        dating = strdt
        timing = strt
        UserDefaults.standard.set(timing, forKey: "timing")
        UserDefaults.standard.set(dating, forKey: "dating")
    }
    
    
    
    
    func checkingCondition(){
        let QRCodeVolueStored = UserDefaults.standard.string(forKey: "QRCodeValue")
        
        if (QRCodeVolueStored == str2){
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(TimeCountDown.action), userInfo: nil, repeats: true)
        }
    }
    
    
    @IBAction func ViewWasDragged(_ sender: UIPanGestureRecognizer) {
        let translation = sender.translation(in: dragView)
        
        sender.view!.center = CGPoint(x: sender.view!.center.x + translation.x, y: sender.view!.center.y + translation.y)
        
        sender.setTranslation(CGPoint.zero, in: self.view)
        
    }
    
    
    
    
    
    @IBAction func EndRideButton(_ sender: Any) {
        
        timer.invalidate()
        
        UserDefaults.standard.set(TimeLabel.text, forKey: "hour")
        UserDefaults.standard.set(MinuteLabel.text, forKey: "minute")
        UserDefaults.standard.set(SecondLabel.text, forKey: "second")
        
        let Ctim = Double(TimeLabel.text!)
        let Cmin = Double(MinuteLabel.text!)
        let Csec = Double(SecondLabel.text!)
        
        let tim = Ctim! * 3600.0
        let min = Cmin! * 60.0
        let totalTim = Csec! + tim + min
        let charge = (totalTim * 0.06)
        let chargeInStr = String(describing: charge)
        UserDefaults.standard.set(chargeInStr, forKey: "charge")
        
        
        SecondLabel.text = "00"
        MinuteLabel.text = "00"
        TimeLabel.text = "00"
        
        UserDefaults.standard.set(true, forKey: "didRide")
        
        
        self.performSegue(withIdentifier: "detailSegue", sender: self)
        
    }
    
    @IBAction func PauseRideButton(_ sender: Any) {
        timer.invalidate()
    }
    
    @IBAction func continueButton(_ sender: Any) {
         timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(TimeCountDown.action), userInfo: nil, repeats: true)
    }
    
    
    @objc func action(){
        second += 01
        SecondLabel.text = String(second)
        if(SecondLabel.text == "60"){
            
            second = 00
            minute += 01
            SecondLabel.text = String(second)
            MinuteLabel.text = String(minute)
        }
        if(MinuteLabel.text == "60"){
            minute = 00
            time += 01
            MinuteLabel.text = String(minute)
            TimeLabel.text = String(time)
        }
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
