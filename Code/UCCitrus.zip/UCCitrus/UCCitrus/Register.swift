//
//  Register.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/1/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit
import FirebaseDatabase

class Register: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var userNameInput: UITextField!
    
    @IBOutlet weak var userEmailInput: UITextField!
    
    @IBOutlet weak var userSchoolIDInput: UITextField!
    
    @IBOutlet weak var userPasswordInput: UITextField!
    
    @IBOutlet weak var userReenterPasswordInput: UITextField!
    
    
    var ref: DatabaseReference?
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.userNameInput.delegate = self
        self.userEmailInput.delegate = self
        self.userSchoolIDInput.delegate = self
        self.userPasswordInput.delegate = self
        self.userReenterPasswordInput.delegate = self

        // Do any additional setup after loading the view.
    }
    
    @IBAction func registerButton(_ sender: Any) {
        
        let userName = userNameInput.text
        let userEmail = userEmailInput.text
        let userSchoolID = userSchoolIDInput.text
        let userPassword = userPasswordInput.text
        let userReenterPassword = userReenterPasswordInput.text
        
        let newPasswordTextField = UITextField()
        
        
        let rulesDescriptor = "required: lower; required: upper; required: digit; minlength: 8;"
        
        if #available(iOS 12.0, *) {
            newPasswordTextField.passwordRules = UITextInputPasswordRules(descriptor: rulesDescriptor)
        } else {
            // Fallback on earlier versions
        }
        
        
        //Checking for Email Validation
        
        let isEmailAddressValid = isValidEmailAddress(emailAddressString: userEmail!)
        
        if isEmailAddressValid
        {
            print("Email address is valid")
        } else {
            print("Email address is not valid")
            displayMyAlertMessage(userMessage: "Email address is not valid")
            return;
        }
        
        //check for empty fields
        
        if(userName?.isEmpty ?? true || userEmail?.isEmpty ?? true || userSchoolID?.isEmpty ?? true ||
            userPassword?.isEmpty ?? true || userReenterPassword?.isEmpty ?? true){
            
            displayMyAlertMessage(userMessage: "All fields are required")
            return;
            
        }
        
        if(userPassword != userReenterPassword){
            //Display an alert message
            displayMyAlertMessage(userMessage: "Passwords do not match")
            return;
        }
        
        if(userSchoolID?.count != 7){
            displayMyAlertMessage(userMessage: "Invalid School ID! Please enter your School ID located under your name on your school ID")
            return;
        }
        
        
        //Display alert message with confirmation
        
        let myAlert = UIAlertController(title: "Alert", message: "Congratulations! 🎉 Your registration was successfull. You are now all set!", preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default){ action in
            self.dismiss(animated: true, completion: nil)
        }
        
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
        
        if((userName != " ") && (userPassword == userReenterPassword) && (isEmailAddressValid) && (userSchoolID?.count == 7)){
            
            //Store data with Database
            
            ref = Database.database().reference()
            let value = [
                "Email Address ": userEmail,
                "School ID ": userSchoolID,
                "Password ": userPassword
            ]
            ref?.child("Citrus Users").child(userName!).childByAutoId().setValue(value)
            
            
            //store data locally
            
            UserDefaults.standard.set(userName, forKey: "userName")
            UserDefaults.standard.set(userEmail, forKey: "userEmail")
            
            UserDefaults.standard.set(userPassword, forKey: "userpasswords")
            
            UserDefaults.standard.set(true, forKey: "isRegistered")
            UserDefaults.standard.synchronize()
            
            
            
            //Display alert message with confirmation
            
            let myAlert = UIAlertController(title: "Alert", message: "Congratulations! 🎉 Your registration was successfull. You are now all set!", preferredStyle: UIAlertController.Style.alert)
            
            let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default){ action in
                self.dismiss(animated: true, completion: nil)
            }
            
            myAlert.addAction(okAction)
            self.present(myAlert, animated: true, completion: nil)
             
        }
        
        
    }
    
    func displayMyAlertMessage(userMessage: String){
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
        
        myAlert.addAction(okAction)
        
        self.present(myAlert, animated: true, completion: nil)
    }
    
    //Hiding the Keyboard
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    //Checking Email Validation
    
    func isValidEmailAddress(emailAddressString: String) -> Bool {
        
        var returnValue = true
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = emailAddressString as NSString
            let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
            
            if results.count == 0
            {
                returnValue = false
            }
            
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        
        return  returnValue
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
