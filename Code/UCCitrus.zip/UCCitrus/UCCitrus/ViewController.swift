//
//  ViewController.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/1/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var userName: UILabel!
    
    @IBOutlet weak var citrusMapView: MKMapView!
    
    @IBOutlet weak var menuView: UIView!
    
    @IBOutlet weak var leadingConstraintView: NSLayoutConstraint!
    
    let locationManager = CLLocationManager()
    
    var menuShowing = false

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        update()
        menuView.layer.shadowOpacity = 1
        menuView.layer.shadowRadius = 5
        
    }
    func update(){
        userName.text = UserDefaults.standard.string(forKey: "userName")
    }
    
    
    
    @IBAction func openMenu(_ sender: Any) {
        
        if(menuShowing){
            leadingConstraintView.constant = -240
            
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
            })
        }
        else{
            leadingConstraintView.constant = 0
            
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
            })
            
        }
        
        menuShowing = !menuShowing
        
    }
    
    
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        let isUserLoggedIn = UserDefaults.standard.bool(forKey: "isUserLoggedIn")
        let isUserRegistered = UserDefaults.standard.bool(forKey: "isRegistered")
        
        if(!isUserLoggedIn || !isUserRegistered){
            self.performSegue(withIdentifier: "loginView", sender: self)
            
            
            citrusMapView.delegate = self
            citrusMapView.showsPointsOfInterest = true
            citrusMapView.showsUserLocation = true
            
            locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
            
            if CLLocationManager.locationServicesEnabled(){
                
                locationManager.delegate = self
                locationManager.desiredAccuracy = kCLLocationAccuracyBest
                locationManager.startUpdatingLocation()
                
            }
            
        }
    }
    
    func locationManager(_ _manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        let location = locations.first!
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
        citrusMapView.setRegion(coordinateRegion, animated: true)
        //locationManager.stopUpdatingLocation()
    }
    
    @IBAction func logoutButton(_ sender: Any) {
        
        UserDefaults.standard.set(false, forKey: "isUserLoggedIn")
        UserDefaults.standard.synchronize()
       self.performSegue(withIdentifier: "loginView", sender: self)
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        leadingConstraintView.constant = -240
        
        UIView.animate(withDuration: 0.3, animations: {
            self.view.layoutIfNeeded()
        })
    }
    
    


}

