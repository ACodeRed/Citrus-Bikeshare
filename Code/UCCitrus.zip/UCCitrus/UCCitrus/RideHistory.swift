//
//  RideHistory.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/2/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit

class RideHistory: UIViewController {
    
    @IBOutlet weak var Currentdate: UILabel!
    
    @IBOutlet weak var Charging: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getCurrentDate()
        // Do any additional setup after loading the view.
    }
    
    func getCurrentDate(){
        
        let didRide = UserDefaults.standard.bool(forKey: "didRide")
        
        if didRide{
            let date = UserDefaults.standard.string(forKey: "dating")
            let timing = UserDefaults.standard.string(forKey: "endtiming")
            
            let to = " - ";
            let time = UserDefaults.standard.string(forKey: "timing")
            Currentdate.text = date! + time! + to + timing!
            
            
            
            let sign = "$"
            let charg = UserDefaults.standard.string(forKey: "charge")
            
            Charging.text = sign + charg!
        }
        else {
            let formatterD = DateFormatter()

            formatterD.dateFormat = "EEEE, MMMM, dd, yyyy, HH:mm:ss a"

            let strd = formatterD.string(from: Date())

            Currentdate.text = strd
        }
        
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
