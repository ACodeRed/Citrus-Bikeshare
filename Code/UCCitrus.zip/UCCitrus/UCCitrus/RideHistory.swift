//
//  RideHistory.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/2/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit

class RideHistory: UIViewController {

    @IBOutlet weak var Currentdate: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getCurrentDate()
        // Do any additional setup after loading the view.
    }
    
    func getCurrentDate(){
        let formatterD = DateFormatter()
        
        formatterD.dateFormat = "EEEE, MMMM, dd, HH:mm a"
        
        let strd = formatterD.string(from: Date())
        
        
        Currentdate.text = strd
       
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
