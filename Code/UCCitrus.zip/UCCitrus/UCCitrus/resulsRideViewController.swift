//
//  resulsRideViewController.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/6/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit

class resulsRideViewController: UIViewController {
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var timeStimeE: UILabel!
    
    @IBOutlet weak var timeSpent: UILabel!
    
    @IBOutlet weak var Charging: UILabel!
    
    var timing = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        update()
        // Do any additional setup after loading the view.
    }
    
    func update(){
        
        let thanks = "Thank you "
        let riding = " for riding Citrus"
        let nameStored = UserDefaults.standard.string(forKey: "userName")
        
        name.text = thanks + nameStored! + riding
        
        let formatterT = DateFormatter()
        formatterT.dateFormat = "HH:mm:ss a"
        let strt = formatterT.string(from: Date())
        timing = strt
        let from = "from "
        let to = " - ";
        let time = UserDefaults.standard.string(forKey: "timing")
        timeStimeE.text = from + time! + to + timing
        UserDefaults.standard.set(timing, forKey: "endtiming")
        
        
        let YouRodeFor = "You rode for "
        let separater = " : "
        let hr = UserDefaults.standard.string(forKey: "hour")
        let min = UserDefaults.standard.string(forKey: "minute")
        let sec = UserDefaults.standard.string(forKey: "second")
        
        timeSpent.text = YouRodeFor + hr! + separater + min! + separater + sec!
        
        let sign = "$"
        let charg = UserDefaults.standard.string(forKey: "charge")
        
        Charging.text = sign + charg!
        
        
    }
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
