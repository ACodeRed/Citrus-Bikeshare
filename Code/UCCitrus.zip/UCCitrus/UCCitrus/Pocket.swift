//
//  Pocket.swift
//  UCCitrus
//
//  Created by tscmac2 on 12/2/18.
//  Copyright © 2018 GrizzlyMobile. All rights reserved.
//

import UIKit

class Pocket: UIViewController {
    
    @IBOutlet var containerViewForCard: UIView!
    
    @IBOutlet weak var viewForGifts: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        UIView.animate(withDuration: 0.3, animations:{
            self.containerViewForCard.alpha = 1.0
            self.viewForGifts.alpha = 1.0
        })
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
